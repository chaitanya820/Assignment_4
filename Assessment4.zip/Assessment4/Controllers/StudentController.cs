﻿using Assessment4.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Assessment4.Controllers
{
        public class StudentController : Controller
        {
            private readonly SchoolContext schoolContext;
            public StudentController()
            {
                schoolContext = new SchoolContext();
            }
            public IActionResult Index()
            {
                var students = schoolContext.Students.ToList();
                return View(students);
            }
            //To Add Student
            public IActionResult Create(Student student)
            {
                var std = schoolContext.Students.Add(student);
                return View(std);
            }

            //Get Student details by studentId 
            public IActionResult details(int id)
            {
                var student = schoolContext.Students.Single(q => q.StudentId == id);
                return View(student);
            }
            //Update Student skill,qualification by  id
            [HttpGet]
            public IActionResult Edit(int id)
            {
                var student = schoolContext.Students.Single(q => q.StudentId == id);
                return View(student);
            }
            [HttpPost]
            public IActionResult Edit(Student student)
            {
                schoolContext.Students.Update(student);
                schoolContext.SaveChanges();
                return RedirectToAction("Index");
            }

            //To delete student by id
            [HttpGet]
            public IActionResult Delete(int id)
            {
                var student = schoolContext.Students.Single(q => q.StudentId == id);
                return View(student);
            }
            [HttpPost]
            public IActionResult Delete(Student student)
            {
                schoolContext.Students.Remove(student);
                schoolContext.SaveChanges();
                return RedirectToAction("Index");
            }
        }
    
}
